package dungeon;

public class Skeleton extends Monster {
	
	   public Skeleton(AttackFactory attackFactory) {
			super("Sargath the Skeleton", 100, 3, "Rusty Blade", .3, 30, 50, attackFactory);
	    }
}
